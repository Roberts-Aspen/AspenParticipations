﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes2Toys
{
    class ToyBox
    {
        //public string List<Toy> { get; set; }


        public ToyBox()
        {
            return;
        }
        
        
    }
}
